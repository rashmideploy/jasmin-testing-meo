import { MasterService } from "./master.service";
import { ValueService } from "./value.service";

describe("MasterService Testing",()=>{
    let masterService:MasterService;
    //1. Testing against Real Value
    it("Should return HelloWorld From Service",()=>{
        masterService = new MasterService(new ValueService());
        expect(masterService.getValue()).toBe("Hello World");
    })
    it("should return fake value from fake service",()=>{
        // fake method
        const fake={getData:()=>'Fake Value'};
        masterService = new MasterService(fake as ValueService);
        expect(masterService.getValue()).toBe("Fake Value");
   
    })
})