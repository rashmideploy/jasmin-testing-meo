import { CalcService } from "./data.service";
import { TestBed } from "@angular/core/testing";

// Jasmine Testing without Angular support

// describe('Data Service',()=>{
//     let service:CalcService;
//     beforeEach(()=>service= new CalcService());
//     it('Addition should return valid value',()=>{
//         expect(service.add(2,3)).toBe(5)
//     })
//     it('Subtract should return a valid value',()=>{
//         expect(service.sub(2,4)).toBe(-2);
//     })
//     it('should be an array with length1',()=>{
//         expect(service.getTodos().length).toBe(1);

//     })
// })


// Using TestBed

describe('Data Service', () => {
    let service: CalcService;
    beforeEach(() => {
        TestBed.configureTestingModule({ providers: [CalcService] })
        service = TestBed.get(CalcService);
    })
    it('Addition should return valid value', () => {
        expect(service.add(2, 3)).toBe(5)
    })
    it('Subtract should return a valid value', () => {
        expect(service.sub(2, 4)).toBe(-2);
    })
    it('should be an array with length1', () => {
        expect(service.getTodos().length).toBe(1);

    })
})
