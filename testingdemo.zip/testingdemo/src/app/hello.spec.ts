// import {helloWorld} from './hello'
// describe('helloWorld',()=>
// {
//     it('says hello',()=>
//     {
//     expect(helloWorld()).toEqual('Hello World');
//     });
// });

import { helloWorld } from './hello';
describe('helloWorldAnkit', () => {

    it('say hellow world Ankit', () => {
        expect(helloWorld()).toEqual('Hello World');

    });
});