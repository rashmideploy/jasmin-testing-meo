import { Injectable } from "@angular/core";

@Injectable()
export class ValueService{
    getData(){
        return "Hello World";
    }
}