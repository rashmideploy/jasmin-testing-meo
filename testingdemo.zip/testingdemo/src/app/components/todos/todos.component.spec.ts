import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TodosComponent } from './todos.component';

describe('TodosComponent', () => {
  let component: TodosComponent;
  let fixture: ComponentFixture<TodosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TodosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TodosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

it(`should have TaskName 'Complete SRS'`,async(()=>{
  const app=fixture.debugElement.componentInstance;
  expect(app.TaskName).toEqual('Complete SRS');

}));


it(`should have as Description 'Software requirements specification'`,async(()=>{
  const app=fixture.debugElement.componentInstance;
  expect(app.Description).toEqual('Software requirements specification');
}));


it(`should have status 'true'`,async(()=>{
  const app=fixture.debugElement.componentInstance;
  expect(app.status).toBeTruthy();
}));
});