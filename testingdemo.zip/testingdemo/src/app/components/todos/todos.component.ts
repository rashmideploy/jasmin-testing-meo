import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-todos',
  templateUrl: './todos.component.html',
  styleUrls: ['./todos.component.css']
})
export class TodosComponent implements OnInit {
TaskName:string ="Complete SRS";
Description :string="Software requirements specification";
status:boolean=true;

  constructor() { }

  ngOnInit() {
  }

}
