
import { Injectable } from '@angular/core';
@Injectable()
export class CalcService{
    todos=[{id:1,name:"Task1"}];
    add(a,b){
        let result =a +b;
        return result;
    }
    sub(a,b){
        let result =a -b;
        return result;
    }
    getTodos(){
        return this.todos;
    }
    
}