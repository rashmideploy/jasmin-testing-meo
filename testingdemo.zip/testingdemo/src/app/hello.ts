// export function helloWorld()
// {
//     return 'Hello World';
// }

export function helloWorld(){
    return 'Hello World';
    }